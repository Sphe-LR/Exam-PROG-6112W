/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestoragereport;

/**
 *
 * @author st10499110 siphesihle mnisi
 */

    
public class FurnitureStorageReport {

    public static void main(String[] args) {

        FurnitureStorage report = new FurnitureStorage();

        System.out.println("FURNITURE STORAGE REPORT - 2026");
        System.out.println("****************************************");

        System.out.println("TOTAL CUSTOMERS: "
                + report.GetTotalCustomers());

        System.out.println("AVERAGE CUSTOMERS: "
                + (int) report.GetAverageCustomers());

        System.out.println("TOWN WITH MOST CUSTOMERS: "
                + report.GetMostPopularTown());

        System.out.println("TOWN WITH LEAST CUSTOMERS: "
                + report.GetLeastPopularTown());
    }
}

interface IFurnitureStorage {

    int GetTotalCustomers();

    double GetAverageCustomers();

    String GetMostPopularTown();

    String GetLeastPopularTown();
}

class FurnitureStorage implements IFurnitureStorage {

    private String[] towns = {"Cape Town", "Durban", "Port Elizabeth"};

    private int[][] customers = {
        {90, 15, 50},
        {125, 55, 91}
    };

    @Override
    public int GetTotalCustomers() {

        int total = 0;

        for (int row = 0; row < customers.length; row++) {
            for (int col = 0; col < customers[row].length; col++) {
                total += customers[row][col];
            }
        }

        return total;
    }

    @Override
    public double GetAverageCustomers() {

        int total = GetTotalCustomers();
        int count = customers.length * customers[0].length;

        return (double) total / count;
    }

    @Override
    public String GetMostPopularTown() {

        int highest = customers[0][0];
        String town = towns[0];

        for (int row = 0; row < customers.length; row++) {
            for (int col = 0; col < customers[row].length; col++) {

                if (customers[row][col] > highest) {
                    highest = customers[row][col];
                    town = towns[col];
                }
            }
        }

        return town + " (" + highest + ")";
    }

    @Override
    public String GetLeastPopularTown() {

        int lowest = customers[0][0];
        String town = towns[0];

        for (int row = 0; row < customers.length; row++) {
            for (int col = 0; col < customers[row].length; col++) {

                if (customers[row][col] < lowest) {
                    lowest = customers[row][col];
                    town = towns[col];
                }
            }
        }

        return town + " (" + lowest + ")";
    }
}

    

    
