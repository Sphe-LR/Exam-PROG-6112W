/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.furniturestorage;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;


public class CalculationsTest {

    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        Calculations calc = new Calculations(1000, 3);

        double expected = 150.0;
        double actual = calc.GetVat();

        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {

        Calculations calc = new Calculations(1000, 3);

        double expected = 3450.0;
        double actual = calc.GetTotalAmount();

        assertEquals(expected, actual, 0.01);
    }
}
    
