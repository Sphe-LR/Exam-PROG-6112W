/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestorage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
/**
 *
 * @author sphe
 */
public class FurnitureStorage extends JFrame {

    private JTextField txtName;
    private JTextField txtPrice;
    private JComboBox<String> cmbDuration;
    private JButton btnProcess;
    private JButton btnSave;

    public FurnitureStorage() {

        setTitle("Furniture Storage");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        JLabel lblName = new JLabel("Customer Name:");
        txtName = new JTextField();

        JLabel lblDuration = new JLabel("Duration:");
        cmbDuration = new JComboBox<>(new String[]{"3", "6", "12"});

        JLabel lblPrice = new JLabel("Price:");
        txtPrice = new JTextField();

        btnProcess = new JButton("PROCESS");
        btnSave = new JButton("SAVE");

        add(lblName);
        add(txtName);

        add(lblDuration);
        add(cmbDuration);

        add(lblPrice);
        add(txtPrice);

        add(btnProcess);
        add(btnSave);

        // Menu
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem saveItem = new JMenuItem("Save");

        fileMenu.add(exitItem);

        toolsMenu.add(processItem);
        toolsMenu.add(saveItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Process Button
        btnProcess.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                processData();
            }
        });

        // Save Button
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveData();
            }
        });

        // Menu Items
        processItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                processData();
            }
        });

        saveItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveData();
            }
        });

        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    private void processData() {

        String name = txtName.getText();
        int duration = Integer.parseInt(cmbDuration.getSelectedItem().toString());
        double price = Double.parseDouble(txtPrice.getText());

        Calculations calc = new Calculations(price, duration);

        JOptionPane.showMessageDialog(this,
                "Customer Name: " + name
                + "\nStorage Duration: " + duration
                + "\nVAT: R " + calc.GetVat()
                + "\nTOTAL: R " + calc.GetTotalAmount());
    }

    private void saveData() {

        try {

            String name = txtName.getText();
            int duration = Integer.parseInt(cmbDuration.getSelectedItem().toString());
            double price = Double.parseDouble(txtPrice.getText());

            Calculations calc = new Calculations(price, duration);

            FileWriter fw = new FileWriter("data.txt");

            fw.write("Customer Name: " + name + "\n");
            fw.write("Storage Duration: " + duration + "\n");
            fw.write("VAT: R " + calc.GetVat() + "\n");
            fw.write("TOTAL: R " + calc.GetTotalAmount());

            fw.close();

            JOptionPane.showMessageDialog(this, "Data Saved");

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, "Error Saving File");
        }
    }

    public static void main(String[] args) {
        new FurnitureStorage().setVisible(true);
    }
}

interface ICalculations {

    double GetVat();

    double GetTotalAmount();
}

class Calculations implements ICalculations {

    private double price;
    private int duration;

    public Calculations(double price, int duration) {
        this.price = price;
        this.duration = duration;
    }

    public double GetVat() {
        return price * 0.15;
    }
    

    public double GetTotalAmount() {
        return (price + GetVat()) * duration;
    }
}